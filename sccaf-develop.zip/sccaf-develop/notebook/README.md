All examples are available at:

https://github.com/SCCAF/sccaf_example
